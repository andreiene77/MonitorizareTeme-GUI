package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

class ConsoleUI {
    private static AppBussines app;
    private static BufferedReader br;
    private final Map<String, Command> menu;
    private final CommandInvoker invoker;

//    TODO: selectie entitati pe baza de alte date in afara de id

    public ConsoleUI() {
        app = new AppBussines();
        br = new BufferedReader(new InputStreamReader(System.in));
        menu = new HashMap<>();
        invoker = new CommandInvoker();

        menu.put("x", new Exit());
        menu.put("s", new ShowAllStudents(app));
        menu.put("t", new ShowAllTemes(app));
        menu.put("n", new AddNota(app, br));
        menu.put("1", new AddStudent(app, br));
        menu.put("2", new ModifStudent(app, br));
        menu.put("3", new FindStudent(app, br));
        menu.put("4", new DeleteStudent(app, br));
        menu.put("5", new AddTema(app, br));
        menu.put("6", new Postpone(app, br));
    }

    private void ShowMenu() {
        System.out.println("Menu: ");
        menu.forEach((key, value) -> System.out.println(" " + key + ". " + value.getMenuEntry()));
    }

    public void runUI() {
        try {
            System.out.println("Introduceti saptamana curenta: ");
            app.setSaptCurenta(br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            ShowMenu();
            try {
                invoker.setCommand(menu.get(br.readLine()));
                invoker.run();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (RuntimeException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}

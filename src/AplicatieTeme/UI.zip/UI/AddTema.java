package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;
import AplicatieTeme.Domain.Tema;

import java.io.BufferedReader;
import java.io.IOException;

public class AddTema implements Command {
    private final AppBussines app;
    private final BufferedReader br;

    public AddTema(AppBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        System.out.println("~ Da-ti datele problemei (id, descriere, deadline, data primirii): ");
        try {
            String line = br.readLine();
            Tema tem = new Tema(line);
            if (app.addTem(tem) == null) {
                System.out.println("Tema adaugata: " + tem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getMenuEntry() {
        return "Adauga tema";
    }
}

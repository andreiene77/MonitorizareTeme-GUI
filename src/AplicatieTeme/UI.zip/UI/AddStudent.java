package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;
import AplicatieTeme.Domain.Student;

import java.io.BufferedReader;
import java.io.IOException;

public class AddStudent implements Command {
    private final AppBussines app;
    private final BufferedReader br;

    public AddStudent(AppBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        System.out.println("~ Da-ti datele studentului (id, nume, grupa, email, prof): ");
        try {
            String line = br.readLine();
            Student stud = new Student(line);
            if (app.addStud(stud) == null) {
                System.out.println("Studentul adaugat: " + stud);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getMenuEntry() {
        return "Adauga student";
    }
}

package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;

import java.io.BufferedReader;
import java.io.IOException;

public class FindStudent implements Command {
    private final AppBussines app;
    private final BufferedReader br;

    public FindStudent(AppBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        System.out.println("~ Da-ti id-ul studentului: ");
        try {
            String id = br.readLine();
            System.out.println(app.findStud(id));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getMenuEntry() {
        return "Cauta student";
    }
}

package AplicatieTeme.UI;

public class Exit implements Command {
    @Override
    public void execute() {
        System.out.println("~ O zi faina!");
        System.exit(0);
    }

    @Override
    public String getMenuEntry() {
        return "Exit";
    }
}

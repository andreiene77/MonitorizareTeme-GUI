package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;

public class ShowAllStudents implements Command {
    private final AppBussines app;

    public ShowAllStudents(AppBussines app) {
        this.app = app;
    }

    @Override
    public void execute() {
        System.out.println("~ Lista cu studenti");
        app.getAll().forEach(System.out::println);
    }

    @Override
    public String getMenuEntry() {
        return "Arata toti studentii";
    }
}

package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class Postpone implements Command {
    private final AppBussines app;
    private final BufferedReader br;

    public Postpone(AppBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        System.out.println("~ Dati id-ul temei, nr. sapt. de amanare: ");
        try {
            String line = br.readLine();
            List<String> attr = Arrays.asList(line.split(", "));
            app.postpone(attr.get(0), attr.get(1));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getMenuEntry() {
        return "Amana deadline tema";
    }
}

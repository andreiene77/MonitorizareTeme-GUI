package AplicatieTeme.UI;

interface Command {
    void execute();

    String getMenuEntry();
}

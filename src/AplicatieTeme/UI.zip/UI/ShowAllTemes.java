package AplicatieTeme.UI;

import AplicatieTeme.Business.AppBussines;

public class ShowAllTemes implements Command {
    private final AppBussines app;

    public ShowAllTemes(AppBussines app) {
        this.app = app;
    }

    @Override
    public void execute() {
        System.out.println("~ Lista cu teme");
        app.getAllTeme().forEach(System.out::println);
    }

    @Override
    public String getMenuEntry() {
        return "Arata toate temele";
    }
}

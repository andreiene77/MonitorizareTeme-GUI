package AplicatieTeme.UI;

import AplicatieTeme.Business.NotaBussines;
import AplicatieTeme.Domain.Nota;

import java.io.BufferedReader;
import java.io.IOException;

public class AddNota implements Command {
    private final NotaBussines app;
    private final BufferedReader br;

    public AddNota(NotaBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        try {
            System.out.println("Alegeti un student (introduceti id-ul):");
            new ShowAllStudents(app).execute();
            String idS = br.readLine();
            System.out.println("Alegeti o tema (introduceti id-ul):");
            new ShowAllTemes(app).execute();
            String idT = br.readLine();
            System.out.println("Introduceti nota (fara penalizari): ");
            float val = Float.parseFloat(br.readLine());
            System.out.println("Feedback: ");
            String feedback = br.readLine();
            Float notaMax = app.addNota(new Nota(idS, idT, val, feedback));
            System.out.println("Nota maxima posibila: " + notaMax);
//            System.out.println(app.findStud(idS).getNumele() + " a primit " +
//                    "nota " + (val - (10 - notaMax)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getMenuEntry() {
        return "Adauga nota";
    }
}

package AplicatieTeme.UI;

import AplicatieTeme.Business.StudentBussines;

import java.io.BufferedReader;
import java.io.IOException;

public class DeleteStudent implements Command {
    private final StudentBussines app;
    private final BufferedReader br;

    public DeleteStudent(StudentBussines app, BufferedReader br) {
        this.app = app;
        this.br = br;
    }

    @Override
    public void execute() {
        System.out.println("~ Da-ti id-ul studentului: ");
        try {
            String id = br.readLine();
            System.out.println("Studentul sters: " + app.removeStud(id));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getMenuEntry() {
        return "Sterge student";
    }
}
